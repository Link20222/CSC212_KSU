public class Utils {
	// Return the reverse of s without changing s.
	public static <U extends Separable<U>> U reverse(U s) {
		return null;
	}
	// Return the last part of s without changing s.
	public static <U extends Separable<U>> U last(U s) {
		return null;
	}
}
