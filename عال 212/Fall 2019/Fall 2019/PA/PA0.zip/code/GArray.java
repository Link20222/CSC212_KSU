class GArray<T> implements Separable<GArray<T>> {
	private T[] data;
	@SuppressWarnings("unchecked")
	public GArray(int n) {
		data = (T[]) new Object[n];
	}
	// Return the element at position i
	public T get(int i) {
		return data[i];
	}
	// Set the element at position i
	public void set(int i, T e) {
		data[i] = e;
	}
	@Override
	public int length() {
		return 0; // Change this
	}
	@Override
	public GArray<T> first() {
		return null; // Change this
	}
	@Override
	public GArray<T> rest() {
		return null; // Change this
	}
	@Override
	public GArray<T> concat(GArray<T> s1, GArray<T> s2) {
		return null; // Change this
	}
}
